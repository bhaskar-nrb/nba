package com.nba.coreproduct.hooks;

import com.nba.automation.base.BaseTest;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import io.cucumber.java.After;
import com.nba.automation.drivers.DriverFactory;

public class TestHooks extends BaseTest {
    @Parameters({"browser"})
    @BeforeMethod(alwaysRun = true)
    public void beforeScenario(@Optional String browser) {
        setUp(browser);
    }

    @AfterMethod(alwaysRun = true)
    public void afterScenario() {
        tearDown();
    }

    @After(order = 100)
    public void cucumberAfterHook() {
        DriverFactory.quitDriver();
    }
}


