package com.nba.coreproduct.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

import java.util.List;

public class WarriorsShopPage {
    private WebDriver driver;
    private WebDriverWait wait;

    @FindBy(css = "nav [aria-label='Shop']")
    WebElement shopMenu;

    @FindBy(linkText = "Men's")
    WebElement mensSection;

    @FindBy(css = ".product-jacket")
    List<WebElement> jacketList;

    @FindBy(css = ".next-page")
    WebElement nextPageButton;

    public WarriorsShopPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void gotoMensSection() {
        wait.until(ExpectedConditions.elementToBeClickable(shopMenu)).click();
        wait.until(ExpectedConditions.elementToBeClickable(mensSection)).click();
    }

    public List<WebElement> getJacketsOnPage() {
        return jacketList;
    }

    public boolean hasNextPage() {
        try {
            return nextPageButton.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public void goToNextPage() {
        nextPageButton.click();
    }
}