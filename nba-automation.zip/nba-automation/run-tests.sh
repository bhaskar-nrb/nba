#!/bin/bash

echo "NBA Test Automation Framework - Test Runner"
echo "=========================================="

echo ""
echo "Available Test Options:"
echo "1. Run All Tests (Parallel)"
echo "2. Run Core Product Tests (Warriors)"
echo "3. Run Derived Product 1 Tests (Sixers)"
echo "4. Run Derived Product 2 Tests (Bulls)"
echo "5. Run with Firefox"
echo "6. Generate Allure Report"
echo "7. Clean and Build"
echo ""

read -p "Enter your choice (1-7): " choice

case $choice in
    1)
        echo "Running all tests in parallel..."
        mvn -DsuiteXmlFile=testng.xml test
        ;;
    2)
        echo "Running Core Product Tests..."
        mvn -pl core-product-tests -am test
        ;;
    3)
        echo "Running Derived Product 1 Tests..."
        mvn -pl derived-product1-tests -am test
        ;;
    4)
        echo "Running Derived Product 2 Tests..."
        mvn -pl derived-product2-tests -am test
        ;;
    5)
        echo "Running all tests with Firefox..."
        mvn -DsuiteXmlFile=testng.xml -Dbrowser=firefox test
        ;;
    6)
        echo "Generating Allure Report..."
        allure serve */target/allure-results
        ;;
    7)
        echo "Cleaning and building project..."
        mvn clean compile
        ;;
    *)
        echo "Invalid choice. Please run the script again."
        ;;
esac

echo ""
echo "Test execution completed."
