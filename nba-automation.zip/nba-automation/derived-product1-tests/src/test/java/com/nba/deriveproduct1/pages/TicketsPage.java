package com.nba.deriveproduct1.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.util.List;

public class TicketsPage {
    private final WebDriver driver;

    @FindBy(css = "section[aria-label='Tickets'] .slide")
    private List<WebElement> slides;

    @FindBy(css = "section[aria-label='Tickets'] .slide .title")
    private List<WebElement> slideTitles;

    @FindBy(css = "section[aria-label='Tickets'] .slide")
    private List<WebElement> slideDurations;

    public TicketsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public int getSlideCount() {
        return slides.size();
    }

    public List<WebElement> getSlideTitles() {
        return slideTitles;
    }
}


