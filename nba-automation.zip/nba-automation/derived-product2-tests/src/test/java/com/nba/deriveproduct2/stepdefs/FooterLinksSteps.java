package com.nba.deriveproduct2.stepdefs;

import com.nba.automation.config.ConfigManager;
import com.nba.automation.drivers.DriverFactory;
import com.nba.automation.utils.DataUtils;
import com.nba.automation.utils.ReportUtils;
import io.cucumber.java.Scenario;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

import java.io.File;
import java.util.*;

public class FooterLinksSteps {
    private WebDriver driver;
    private List<String> hrefs = new ArrayList<>();
    private WebDriverWait wait;

    @Given("I am on the DP2 homepage")
    public void iAmOnDp2Homepage() {
        driver = DriverFactory.getDriver();
        driver.get(ConfigManager.getConfig("dp2.url"));
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    @When("I scroll to the footer and collect all links")
    public void collectLinks() {
        // Scroll to bottom with stabilization to ensure lazy content loads
        long lastHeight = (long) ((JavascriptExecutor) driver).executeScript("return document.body.scrollHeight");
        for (int i = 0; i < 5; i++) {
            ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight);");
            try { Thread.sleep(700); } catch (InterruptedException ignored) {}
            long newHeight = (long) ((JavascriptExecutor) driver).executeScript("return document.body.scrollHeight");
            if (newHeight == lastHeight) break;
            lastHeight = newHeight;
        }

        // Wait for footer to be present/visible
        WebElement footer = wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("footer")));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", footer);
        wait.until(ExpectedConditions.visibilityOf(footer));

        List<WebElement> anchors = driver.findElements(By.cssSelector("footer a[href]"));
        for (WebElement a : anchors) {
            String href = a.getAttribute("href");
            if (href != null && !href.isEmpty()) {
                hrefs.add(href);
            }
        }
    }

    private Scenario scenario;

    @Before
    public void before(Scenario s) { this.scenario = s; }

    @Then("I write links to CSV and report duplicates")
    public void writeCsvAndReport() {
        List<Map<String, String>> rows = new ArrayList<>();
        for (String h : hrefs) {
            Map<String, String> r = new HashMap<>();
            r.put("href", h);
            rows.add(r);
        }
        File csv = DataUtils.writeCsv(rows, "dp2_footer_links.csv");
        ReportUtils.attachFile(scenario, csv, "DP2 Footer Links");

        Set<String> seen = new HashSet<>();
        Set<String> dupes = new LinkedHashSet<>();
        for (String h : hrefs) {
            if (!seen.add(h)) {
                dupes.add(h);
            }
        }
        if (!dupes.isEmpty()) {
            scenario.attach(String.join("\n", dupes).getBytes(), "text/plain", "Duplicate Links");
        }
    }
}


