# NBA Test Automation Framework

A comprehensive multi-module Maven project for automated testing of NBA websites using Selenium WebDriver, Cucumber BDD, and TestNG.

## Framework Architecture

```
nba-automation/
├── automation-framework/          # Core framework module
│   ├── src/main/java/com/nba/automation/
│   │   ├── base/                  # Base test classes
│   │   ├── config/                # Configuration management
│   │   ├── drivers/               # WebDriver factory
│   │   ├── utils/                 # Utility classes
│   │   └── reporting/             # Reporting utilities
│   └── src/main/resources/
│       └── config.properties      # Framework configuration
├── core-product-tests/            # Warriors (CP) test module
├── derived-product1-tests/         # Sixers (DP1) test module
├── derived-product2-tests/         # Bulls (DP2) test module
└── testng.xml                     # Root test suite
```

## Quick Start

### Prerequisites
- Java 11 or higher
- Maven 3.6+
- Chrome/Firefox browsers
- Internet connection

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd nba-automation
   ```

2. **Build the project**
   ```bash
   mvn clean compile
   ```

3. **Run all tests**
   ```bash
   mvn test
   ```

## Test Execution

### Run All Modules (Parallel Execution)
```bash
mvn -DsuiteXmlFile=testng.xml test
```

### Run Individual Modules

**Core Product (Warriors)**
```bash
mvn -pl core-product-tests -am test
```

**Derived Product 1 (Sixers)**
```bash
mvn -pl derived-product1-tests -am test
```

**Derived Product 2 (Bulls)**
```bash
mvn -pl derived-product2-tests -am test
```

### Browser Selection
```bash
# Chrome (default)
mvn test

# Firefox
mvn test -Dbrowser=firefox
```

##  Test Scenarios

### Core Product (Warriors)
- **Jacket Data Extraction**: Navigate to men's shop, extract jacket details (price, title, top seller) across all pages, save to text file

### Derived Product 1 (Sixers)
- **Tickets Slider Validation**: Count slides under Tickets section, validate titles and durations

### Derived Product 2 (Bulls)
- **Footer Links Analysis**: Extract all footer links, generate CSV report, detect duplicates

## Reporting

### Allure Reports
```bash
# Generate Allure report
allure serve */target/allure-results

# Or serve specific module
allure serve core-product-tests/target/allure-results
```

### TestNG Reports
- Location: `*/target/surefire-reports/`
- Open `index.html` in browser

### Cucumber Reports
- Location: `*/target/cucumber-report.html`

## Configuration

### Environment Variables
```properties
# config.properties
browser=chrome
cp.url=https://www.nba.com/warriors
dp1.url=https://www.nba.com/sixers/
dp2.url=https://www.nba.com/bulls/
cp.shop.mens.url=https://store.nba.com/golden-state-warriors/mens/...
```

### Browser Configuration
- **Chrome**: Uses WebDriverManager for automatic driver management
- **Firefox**: Uses WebDriverManager for automatic driver management
- **Headless**: Add `-Dheadless=true` to Maven command

## Framework Features

### Design Patterns
- **Page Object Model**: Organized page classes with WebElement locators
- **Factory Pattern**: Centralized WebDriver management
- **Builder Pattern**: Configuration management
- **Singleton**: Thread-safe driver instances

### Key Components

#### DriverFactory
```java
// Thread-safe WebDriver management
WebDriver driver = DriverFactory.getDriver();
DriverFactory.quitDriver();
```

#### BaseTest
```java
// Framework-agnostic base class
public abstract class BaseTest {
    protected WebDriver driver;
    public void setUp(String browser) { ... }
    public void tearDown() { ... }
}
```

#### ConfigManager
```java
// Centralized configuration
String url = ConfigManager.getConfig("cp.url");
String browser = ConfigManager.getConfig("browser");
```

### Utilities
- **WaitUtils**: Explicit waits and synchronization
- **DataUtils**: File operations (CSV, text files)
- **ReportUtils**: Test artifact attachments

## Troubleshooting

### Common Issues

1. **Browser not found**
   - Ensure Chrome/Firefox is installed
   - WebDriverManager handles driver downloads automatically

2. **Tests timeout**
   - Increase wait timeouts in `WaitUtils`
   - Check network connectivity

3. **Element not found**
   - Verify selectors match current website structure
   - Add explicit waits for dynamic content

### Debug Mode
```bash
# Run with debug logging
mvn test -X

# Run specific test class
mvn test -Dtest=CucumberTestRunner
```

## Project Structure

```
src/
├── main/java/com/nba/
│   ├── automation/                 # Framework core
│   │   ├── base/BaseTest.java
│   │   ├── config/ConfigManager.java
│   │   ├── drivers/DriverFactory.java
│   │   └── utils/
│   ├── coreproduct/               # CP tests
│   ├── deriveproduct1/            # DP1 tests
│   └── deriveproduct2/            # DP2 tests
└── test/resources/
    ├── features/                  # Gherkin scenarios
    └── testng.xml                 # TestNG suites
```

## CI/CD Integration

### GitHub Actions Example
```yaml
name: NBA Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-java@v2
        with:
          java-version: '11'
      - name: Run Tests
        run: mvn test
      - name: Upload Reports
        uses: actions/upload-artifact@v2
        with:
          name: test-reports
          path: */target/
```

## Best Practices

1. **Page Objects**: Keep locators in page classes
2. **Waits**: Use explicit waits over implicit waits
3. **Data**: Externalize test data to properties/JSON files
4. **Reports**: Attach screenshots for failures
5. **Cleanup**: Always quit drivers in @After hooks

## Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For questions or issues:
- Create an issue in the repository
- Check existing documentation
- Review test logs in `target/surefire-reports/`
