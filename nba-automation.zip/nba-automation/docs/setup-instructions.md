# NBA Test Automation Framework - Setup Instructions

## 🚀 Quick Setup Guide

### Prerequisites
- **Java 11 or higher** ([Download](https://adoptium.net/))
- **Maven 3.6+** ([Download](https://maven.apache.org/download.cgi))
- **Chrome/Firefox browsers** (latest versions)
- **Internet connection** (for WebDriverManager and NBA websites)

### Windows Setup

1. **Install Java 11+**
   ```cmd
   # Verify installation
   java -version
   javac -version
   ```

2. **Install Maven**
   ```cmd
   # Add to PATH: C:\apache-maven-3.9.9\bin
   # Verify installation
   mvn -version
   ```

3. **Clone and Build**
   ```cmd
   git clone <repository-url>
   cd nba-automation
   mvn clean compile
   ```

4. **Run Tests**
   ```cmd
   # Option 1: Use batch script
   run-tests.bat
   
   # Option 2: Direct Maven commands
   mvn test
   ```

### macOS/Linux Setup

1. **Install Java 11+**
   ```bash
   # Using Homebrew (macOS)
   brew install openjdk@11
   
   # Using package manager (Linux)
   sudo apt-get install openjdk-11-jdk
   ```

2. **Install Maven**
   ```bash
   # Using Homebrew (macOS)
   brew install maven
   
   # Using package manager (Linux)
   sudo apt-get install maven
   ```

3. **Clone and Build**
   ```bash
   git clone <repository-url>
   cd nba-automation
   mvn clean compile
   ```

4. **Run Tests**
   ```bash
   # Option 1: Use shell script
   ./run-tests.sh
   
   # Option 2: Direct Maven commands
   mvn test
   ```

## 🔧 Configuration

### Browser Configuration
```properties
# config.properties
browser=chrome                    # chrome, firefox
headless=false                   # true for headless mode
```

### Environment Variables
```bash
# Optional: Override default browser
export BROWSER=firefox

# Optional: Set headless mode
export HEADLESS=true
```

## 🧪 Test Execution Options

### Run All Tests (Recommended)
```bash
mvn -DsuiteXmlFile=testng.xml test
```

### Run Individual Modules
```bash
# Warriors tests
mvn -pl core-product-tests -am test

# Sixers tests  
mvn -pl derived-product1-tests -am test

# Bulls tests
mvn -pl derived-product2-tests -am test
```

### Browser Selection
```bash
# Chrome (default)
mvn test

# Firefox
mvn test -Dbrowser=firefox

# Headless Chrome
mvn test -Dheadless=true
```

## 📊 Report Generation

### Allure Reports (Recommended)
```bash
# Install Allure CLI first
npm install -g allure-commandline

# Generate report
allure serve */target/allure-results
```

### TestNG Reports
```bash
# Open in browser
open */target/surefire-reports/index.html
```

### Cucumber Reports
```bash
# Open in browser
open */target/cucumber-report.html
```

## 🐛 Troubleshooting

### Common Issues

1. **Java Version Error**
   ```bash
   # Check Java version
   java -version
   # Should show Java 11 or higher
   ```

2. **Maven Not Found**
   ```bash
   # Add Maven to PATH
   export PATH=$PATH:/path/to/maven/bin
   ```

3. **Browser Driver Issues**
   ```bash
   # WebDriverManager handles this automatically
   # Ensure Chrome/Firefox are installed
   ```

4. **Network Issues**
   ```bash
   # Check internet connection
   # NBA websites must be accessible
   ```

### Debug Mode
```bash
# Run with debug logging
mvn test -X

# Run specific test class
mvn test -Dtest=CucumberTestRunner
```

## 📁 Project Structure After Setup

```
nba-automation/
├── automation-framework/          # Core framework
├── core-product-tests/            # Warriors tests
├── derived-product1-tests/         # Sixers tests
├── derived-product2-tests/         # Bulls tests
├── docs/                          # Documentation
├── run-tests.bat                  # Windows runner
├── run-tests.sh                   # Unix runner
├── README.md                      # Main documentation
└── testng.xml                     # Root test suite
```

## 🚀 CI/CD Integration

### GitHub Actions
```yaml
name: NBA Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-java@v2
        with:
          java-version: '11'
      - name: Run Tests
        run: mvn test
      - name: Upload Reports
        uses: actions/upload-artifact@v2
        with:
          name: test-reports
          path: */target/
```

### Jenkins Pipeline
```groovy
pipeline {
    agent any
    stages {
        stage('Build') {
            steps {
                sh 'mvn clean compile'
            }
        }
        stage('Test') {
            steps {
                sh 'mvn test'
            }
        }
        stage('Report') {
            steps {
                allure([
                    includeProperties: false,
                    jdk: '',
                    properties: [],
                    reportBuildPolicy: 'ALWAYS',
                    results: [[path: '*/target/allure-results']]
                ])
            }
        }
    }
}
```

## 📞 Support

### Getting Help
1. **Check logs**: `*/target/surefire-reports/`
2. **Review documentation**: `README.md` and `docs/`
3. **Verify setup**: Run `mvn -version` and `java -version`
4. **Test connectivity**: Ensure NBA websites are accessible

### Common Commands
```bash
# Clean build
mvn clean compile

# Run with specific browser
mvn test -Dbrowser=firefox

# Generate reports
allure serve */target/allure-results

# Debug mode
mvn test -X
```

## ✅ Verification Checklist

- [ ] Java 11+ installed and on PATH
- [ ] Maven 3.6+ installed and on PATH
- [ ] Chrome/Firefox browsers installed
- [ ] Internet connection working
- [ ] Project builds successfully (`mvn clean compile`)
- [ ] Tests run successfully (`mvn test`)
- [ ] Reports generate correctly
- [ ] All modules execute independently

## 🎯 Next Steps

1. **Run the full test suite** to verify setup
2. **Review generated reports** for test results
3. **Customize configuration** as needed
4. **Add additional test scenarios** if required
5. **Integrate with CI/CD** pipeline

The framework is now ready for use! 🚀
