package com.nba.automation.utils;

import java.util.*;
import java.io.*;

public class DataUtils {
    public static void writeToTextFile(List<Map<String, String>> data, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Map<String, String> map : data) {
                writer.write(map.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static File writeCsv(List<Map<String, String>> rows, String filename) {
        if (rows == null || rows.isEmpty()) {
            try {
                File f = new File(filename);
                if (!f.exists()) f.createNewFile();
                return f;
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        Set<String> headers = rows.get(0).keySet();
        try (PrintWriter pw = new PrintWriter(new FileWriter(filename))) {
            pw.println(String.join(",", headers));
            for (Map<String, String> row : rows) {
                List<String> values = new ArrayList<>();
                for (String h : headers) {
                    String v = row.getOrDefault(h, "");
                    if (v.contains(",") || v.contains("\"")) {
                        v = '"' + v.replace("\"", "\"\"") + '"';
                    }
                    values.add(v);
                }
                pw.println(String.join(",", values));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return new File(filename);
    }
}