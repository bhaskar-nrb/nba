package com.nba.automation.base;

import com.nba.automation.drivers.DriverFactory;
import org.openqa.selenium.WebDriver;

public abstract class BaseTest {
    protected WebDriver driver;

    public void setUp(String browser) {
        if (browser != null && !browser.isEmpty()) {
            System.setProperty("browser", browser);
        }
        driver = DriverFactory.getDriver();
    }

    public void tearDown() {
        DriverFactory.quitDriver();
    }
}