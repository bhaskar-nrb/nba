package com.nba.automation.utils;

import io.cucumber.java.Scenario;

import java.io.File;
import java.nio.file.Files;

public class ReportUtils {
    public static void attachFile(Scenario scenario, File file, String name) {
        try {
            if (file != null && file.exists()) {
                byte[] content = Files.readAllBytes(file.toPath());
                scenario.attach(content, "text/plain", name);
            }
        } catch (Exception ignored) {
        }
    }
}


